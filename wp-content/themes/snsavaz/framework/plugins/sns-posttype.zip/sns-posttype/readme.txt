=== SNS Post Type ===
Contributors: SNSTheme
Website: http://snstheme.com
Tags: snstheme, posttype